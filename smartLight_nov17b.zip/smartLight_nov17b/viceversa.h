const char VICEVERSA_page[] PROGMEM = R"=====(
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Vice Versa</title>
</head>
<body >
  <h1>Vice Versa</h1>

  <form action="/L" >
      <textarea style="border-radius: 15px 15px 15px 2px;" id="msg" name="user_message" cols ="50" rows="10" placeholder="{{userreversemessage}}"></textarea>
      <br>
      <br>
      <input style="border-radius: 2px 8px 8px 8px; ; padding: 10px" type="submit" value="Reverse!">
  </form>

</body>
</html>
)=====";
