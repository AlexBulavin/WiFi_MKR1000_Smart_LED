const char VICEREVERSA_page[] PROGMEM = R"=====(
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reverse page</title>
</head>
<body style="background-color:black">
<h1 style="color: grey">asreV eciV</h1>
<form action="/H">
    <textarea style="color: white; background-color: darkgrey; border-radius: 15px 15px 2px 15px; skew: 20deg;" id="reverse_msg" name="user_reverse_message" cols ="50" rows="10" placeholder="Reverse message: {{usermessage}} Words count: {{wordscount}}"></textarea>
    <br>
    <br>
    <input style="color: white; background-color: darkgrey; border-radius: 8px 2px 8px 8px; margin: 0px 300px; padding: 10px" type="submit" value="Reverse again!">
</form>

</body>
</html>
)=====";
