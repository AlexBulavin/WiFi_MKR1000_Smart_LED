p {
       background: #fff;
       border-radius: 7px;
       box-shadow: 0 2px 5px #ccc;
       padding: 10px;
       width: 240px;
       height: 260px;
       margin: 16px;
       float: left;
   }

 h2 {
    font-family: "Montserrat", sans-serif;
 }
 
